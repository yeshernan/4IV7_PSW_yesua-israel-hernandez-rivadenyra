/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mysql.conexion;

/**
 *
 * @author yeshe
 */
public class conexion {

public static string DRIVER ="com.mysql.jdbc.Driver";
public static string usuario="root"
public static string PASSWORD ="saocro45"
public static string URL ="jdbd:mysql://localhost:3306/reclamos"

static{
     try{
      Class.forName(DRIVER);
     }catch (ClassNotFoundExpetations e) {
       JOptionpane.showMessageDialog(null,"error en el driver:" + e);
}
}
   
public connection getconnection(){

    Connection con = null;
    try{
        con = DriveManager:getConnection(URL, usuario, PASSWORD);
         JOptionpane.showMessageDialog(null,"conexion exitosa:"); 
    }catch (ClassNotFoundExpetations e){
      JOptionpane.showMessageDialog(null,"ERROR EN LA CONEXION:" + e);
    }
     return con;
  }
}
