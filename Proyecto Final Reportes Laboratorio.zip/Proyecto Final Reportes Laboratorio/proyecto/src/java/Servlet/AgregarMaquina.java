/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//importar librerias
import java.sql.*;
import javax.servlet.ServletConfig;

/**
 *
 * @author USER
 */
public class AgregarMaquina extends HttpServlet {

         
    // Para evitar que cualquiera se meta a mi BD tienen que ser private
    
   
    private Connection con;
    private Statement set;
    private ResultSet rs;
    
     //definiendo el constructor de la clase
    
    public void init(ServletConfig cfg) throws ServletException{
        //defino como se conecta a la base de datos
        String URL = "jdbc:mysql:3060//localhost/maquinasbatiz";
                     //tipo de conector:manejadorbd:puerto//ip/nombrebd
        String userName = "root";
        String password = "Yonosoyuriel1";     
        
        try{
            //lo primero es conectarnos
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            URL = "jdbc:mysql://localhost/maquinasbatiz";
            con = DriverManager.getConnection(URL, userName, password);
            set = con.createStatement();
            
            System.out.println("Se ha conectado exitosamente <3 ");            
            
        } catch (Exception e){
            System.out.println("No se ha conectado exitosamente :C ");
            System.out.println(e.getMessage());
            System.out.println(e.getStackTrace());
        }
        
    
    }

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>AgregarMaquina</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Agregar maquina</h1>");
            
               try{
                //obtener los parametros para poder
                //insertarlos en la BD
                String nom, appat, apmat, user, pass, fecha, sexo, nEmpleado;
                
                user = request.getParameter("usuario").trim();
                pass = request.getParameter("password").trim();
                nom = request.getParameter("nombre").trim();
                appat = request.getParameter("appat").trim();
                apmat = request.getParameter("apmat").trim();
                fecha = request.getParameter("fecha").trim();
                sexo = request.getParameter("sexo").trim();
                nEmpleado = request.getParameter("empleado").trim();
                
                System.out.println(user);
                System.out.println(pass);
                System.out.println(nom);
                System.out.println(nEmpleado);
                System.out.println(fecha);
                System.out.println(sexo);
                System.out.println(appat);
                System.out.println(apmat);
                
                
                if(!"".equals(user) && !"".equals(pass) && !"".equals(nom) && !"".equals(nEmpleado) && !"".equals(fecha) &&
                !"".equals(sexo) && !"".equals(appat) && !"".equals(apmat)){
                    //querry
                    String q = "insert into MPersona "
                            + "values (NULL,NULL,"+nEmpleado+", '"+nom+"', '"+appat+"', '"+apmat+"', '"+sexo+"', '"+fecha+"', '"+user+"', '"+pass+"', 1, 2, 3)";
                    
              //      String q = "insert into MPersona values" +
                //                "(5 , NULL, 2,'Jaime', 'Minor', 'Perez', 'Masculino', '2000-12-21', 'minor', 'soyjaime123', 1, 2, 3)";
                    System.out.println("Dato registrado");
                    System.out.println(q);
                    //se ejecuta la sentencia
                    
                    set.executeUpdate(q);
                    out.println("<h1>Registro Exitoso</h1>");
                    out.println("<img src='img/gatitoBien.gif' alt=''>");
                    System.out.println("Se registro un nuevo alumno");  
                }else{
                    out.println("<h1>No se pude registrar el Alumno</h1>");
                    out.println("<h2>No puedes dejar espacios en blanco</h2>");
                    out.println("<img src='img/gatitoMal.gif' alt=''>");
                }
            
            }catch(Exception e){
                
                System.out.println("No se pudo registrar verificar los datos de entrada unu");
                System.out.println(e.getMessage());
                System.out.println(e.getStackTrace());
                out.println("<h1 class='titulo2'>No se pudo Registrar el Docente, hay un error unu.</h1>");
            
            }
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
