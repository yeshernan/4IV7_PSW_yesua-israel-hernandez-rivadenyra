/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author cerna
 */
public class MCpu {
    private String cpu_serial;
    private String cpu_descripcion;
    
    public MCpu(){
        cpu_serial="";
        cpu_descripcion="";
    }

    public String getCpu_serial() {
        return cpu_serial;
    }

    public void setCpu_serial(String cpu_serial) {
        this.cpu_serial = cpu_serial;
    }

    public String getCpu_descripcion() {
        return cpu_descripcion;
    }

    public void setCpu_descripcion(String cpu_descripcion) {
        this.cpu_descripcion = cpu_descripcion;
    }
    
}
