/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author cerna
 */
public class CMarca {
    private int marca_id;
    private String marca_nom;
    
    public CMarca(){
        marca_id=0;
        marca_nom="";
    }

    public int getMarca_id() {
        return marca_id;
    }

    public void setMarca_id(int marca_id) {
        this.marca_id = marca_id;
    }

    public String getMarca_nom() {
        return marca_nom;
    }

    public void setMarca_nom(String marca_nom) {
        this.marca_nom = marca_nom;
    }
    
}
