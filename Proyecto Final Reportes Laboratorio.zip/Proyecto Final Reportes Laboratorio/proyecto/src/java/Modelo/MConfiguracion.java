/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author cerna
 */
public class MConfiguracion {
    private int config_id;
    private String config_descripcion;
    
    public MConfiguracion(){
        config_id=0;
        config_descripcion="";
    }

    public int getConfig_id() {
        return config_id;
    }

    public void setConfig_id(int config_id) {
        this.config_id = config_id;
    }

    public String getConfig_descripcion() {
        return config_descripcion;
    }

    public void setConfig_descripcion(String config_descripcion) {
        this.config_descripcion = config_descripcion;
    }
    
}
