/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author cerna
 */
public class DReporte {
    private int detalleReporte_id;
    private String detalleReporte_fecha;
    private String detalleReporte_hora;
    private EEquiposreportados equiposRepor_id;
    private EReportespersona reportePer_id;
    private CPrioridad prioridad_id;
    private CEstadoreporte edoRe_id;
    private MReporte maestraReporte_id;
    private CAsignatura asignatura_id;
    
    public DReporte(){
        detalleReporte_id=0;
        detalleReporte_fecha="";
        detalleReporte_hora="";
        
        equiposRepor_id= new EEquiposreportados();
        reportePer_id= new EReportespersona();
        prioridad_id= new CPrioridad();
        edoRe_id= new CEstadoreporte();
        maestraReporte_id= new MReporte();
        asignatura_id= new CAsignatura();
    }

    public int getDetalleReporte_id() {
        return detalleReporte_id;
    }

    public void setDetalleReporte_id(int detalleReporte_id) {
        this.detalleReporte_id = detalleReporte_id;
    }

    public String getDetalleReporte_fecha() {
        return detalleReporte_fecha;
    }

    public void setDetalleReporte_fecha(String detalleReporte_fecha) {
        this.detalleReporte_fecha = detalleReporte_fecha;
    }

    public String getDetalleReporte_hora() {
        return detalleReporte_hora;
    }

    public void setDetalleReporte_hora(String detalleReporte_hora) {
        this.detalleReporte_hora = detalleReporte_hora;
    }

    public EEquiposreportados getEquiposRepor_id() {
        return equiposRepor_id;
    }

    public void setEquiposRepor_id(EEquiposreportados equiposRepor_id) {
        this.equiposRepor_id = equiposRepor_id;
    }

    public EReportespersona getReportePer_id() {
        return reportePer_id;
    }

    public void setReportePer_id(EReportespersona reportePer_id) {
        this.reportePer_id = reportePer_id;
    }

    public CPrioridad getPrioridad_id() {
        return prioridad_id;
    }

    public void setPrioridad_id(CPrioridad prioridad_id) {
        this.prioridad_id = prioridad_id;
    }

    public CEstadoreporte getEdoRe_id() {
        return edoRe_id;
    }

    public void setEdoRe_id(CEstadoreporte edoRe_id) {
        this.edoRe_id = edoRe_id;
    }

    public MReporte getMaestraReporte_id() {
        return maestraReporte_id;
    }

    public void setMaestraReporte_id(MReporte maestraReporte_id) {
        this.maestraReporte_id = maestraReporte_id;
    }

    public CAsignatura getAsignatura_id() {
        return asignatura_id;
    }

    public void setAsignatura_id(CAsignatura asignatura_id) {
        this.asignatura_id = asignatura_id;
    }
    
}
