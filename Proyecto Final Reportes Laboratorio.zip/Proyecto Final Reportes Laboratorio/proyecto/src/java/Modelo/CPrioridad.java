/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author cerna
 */
public class CPrioridad {
    private int prioridad_id;
    private String prioridad_tipo;
    
    public CPrioridad(){
        prioridad_id=0;
        prioridad_tipo="";
    }

    public int getPrioridad_id() {
        return prioridad_id;
    }

    public void setPrioridad_id(int prioridad_id) {
        this.prioridad_id = prioridad_id;
    }

    public String getPrioridad_tipo() {
        return prioridad_tipo;
    }

    public void setPrioridad_tipo(String prioridad_tipo) {
        this.prioridad_tipo = prioridad_tipo;
    }
    
}
