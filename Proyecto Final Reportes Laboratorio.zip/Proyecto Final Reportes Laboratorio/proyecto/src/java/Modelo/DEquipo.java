/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author cerna
 */
public class DEquipo {
    private int equipo_etiqueta;
    private String problema;
    private CLaboratorio lab_id;
    private CMarca marca_id;
    private MCpu cpu_serial;
    private MAccesorio accesorio_id;
    private MMonitor monitor_id;
    private MConfiguracion config_id;
    private CEdoequipo edoEquipo_id;
    
    public DEquipo(){
        equipo_etiqueta=0;
        problema="";
        
        lab_id= new CLaboratorio();
        marca_id= new CMarca();
        cpu_serial= new MCpu();
        accesorio_id= new MAccesorio();
        monitor_id= new MMonitor();
        config_id= new MConfiguracion();
        edoEquipo_id= new CEdoequipo();
    }

    public int getEquipo_etiqueta() {
        return equipo_etiqueta;
    }

    public void setEquipo_etiqueta(int equipo_etiqueta) {
        this.equipo_etiqueta = equipo_etiqueta;
    }

    public String getProblema() {
        return problema;
    }

    public void setProblema(String problema) {
        this.problema = problema;
    }

    public CLaboratorio getLab_id() {
        return lab_id;
    }

    public void setLab_id(CLaboratorio lab_id) {
        this.lab_id = lab_id;
    }

    public CMarca getMarca_id() {
        return marca_id;
    }

    public void setMarca_id(CMarca marca_id) {
        this.marca_id = marca_id;
    }

    public MCpu getCpu_serial() {
        return cpu_serial;
    }

    public void setCpu_serial(MCpu cpu_serial) {
        this.cpu_serial = cpu_serial;
    }

    public MAccesorio getAccesorio_id() {
        return accesorio_id;
    }

    public void setAccesorio_id(MAccesorio accesorio_id) {
        this.accesorio_id = accesorio_id;
    }

    public MMonitor getMonitor_id() {
        return monitor_id;
    }

    public void setMonitor_id(MMonitor monitor_id) {
        this.monitor_id = monitor_id;
    }

    public MConfiguracion getConfig_id() {
        return config_id;
    }

    public void setConfig_id(MConfiguracion config_id) {
        this.config_id = config_id;
    }

    public CEdoequipo getEdoEquipo_id() {
        return edoEquipo_id;
    }

    public void setEdoEquipo_id(CEdoequipo edoEquipo_id) {
        this.edoEquipo_id = edoEquipo_id;
    }
    
    
}
