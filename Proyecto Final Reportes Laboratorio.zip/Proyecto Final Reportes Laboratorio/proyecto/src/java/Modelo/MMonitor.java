/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author cerna
 */
public class MMonitor {
    private String monitor_id;
    private String monitor_descripcion;
    
    public MMonitor(){
        monitor_id="";
        monitor_descripcion="";
    }

    public String getMonitor_id() {
        return monitor_id;
    }

    public void setMonitor_id(String monitor_id) {
        this.monitor_id = monitor_id;
    }

    public String getMonitor_descripcion() {
        return monitor_descripcion;
    }

    public void setMonitor_descripcion(String monitor_descripcion) {
        this.monitor_descripcion = monitor_descripcion;
    }
    
}
