/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author cerna
 */
public class CEdoequipo {
    private int edoEquipo_id;
    private String edoEquipo_tipo;
    
    public CEdoequipo(){
        edoEquipo_id=0;
        edoEquipo_tipo="";
    }

    public int getEdoEquipo_id() {
        return edoEquipo_id;
    }

    public void setEdoEquipo_id(int edoEquipo_id) {
        this.edoEquipo_id = edoEquipo_id;
    }

    public String getEdoEquipo_tipo() {
        return edoEquipo_tipo;
    }

    public void setEdoEquipo_tipo(String edoEquipo_tipo) {
        this.edoEquipo_tipo = edoEquipo_tipo;
    }
    
}
