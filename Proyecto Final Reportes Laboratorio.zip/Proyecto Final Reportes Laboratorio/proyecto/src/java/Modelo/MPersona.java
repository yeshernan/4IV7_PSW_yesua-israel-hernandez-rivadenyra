/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author cerna
 */
public class MPersona {
    private int persona_id;
    private int alumno_boleta;
    private int empleado_num;
    private String persona_nombre;
    private String persona_appat;
    private String persona_appmat;
    private String persona_sexo;
    private String persona_fechaNacimiento;
    private String persona_user;
    private String persona_pass;
    
    private CRol rol_id;
    private CPrivilegio privilegio_id;
    private CGrupo grupo_id;
    
    public MPersona(){
        persona_id=0;
        alumno_boleta=0;
        empleado_num=0;
        persona_nombre="";
        persona_appat="";
        persona_appmat="";
        persona_sexo="";
        persona_fechaNacimiento="";
        persona_user="";
        persona_pass="";
        
        rol_id= new CRol();
        privilegio_id= new CPrivilegio();
        grupo_id= new CGrupo();
    }

    public int getPersona_id() {
        return persona_id;
    }

    public void setPersona_id(int persona_id) {
        this.persona_id = persona_id;
    }

    public int getAlumno_boleta() {
        return alumno_boleta;
    }

    public void setAlumno_boleta(int alumno_boleta) {
        this.alumno_boleta = alumno_boleta;
    }

    public int getEmpleado_num() {
        return empleado_num;
    }

    public void setEmpleado_num(int empleado_num) {
        this.empleado_num = empleado_num;
    }

    public String getPersona_nombre() {
        return persona_nombre;
    }

    public void setPersona_nombre(String persona_nombre) {
        this.persona_nombre = persona_nombre;
    }

    public String getPersona_appat() {
        return persona_appat;
    }

    public void setPersona_appat(String persona_appat) {
        this.persona_appat = persona_appat;
    }

    public String getPersona_appmat() {
        return persona_appmat;
    }

    public void setPersona_appmat(String persona_appmat) {
        this.persona_appmat = persona_appmat;
    }

    public String getPersona_sexo() {
        return persona_sexo;
    }

    public void setPersona_sexo(String persona_sexo) {
        this.persona_sexo = persona_sexo;
    }

    public String getPersona_fechaNacimiento() {
        return persona_fechaNacimiento;
    }

    public void setPersona_fechaNacimiento(String persona_fechaNacimiento) {
        this.persona_fechaNacimiento = persona_fechaNacimiento;
    }

    public String getPersona_user() {
        return persona_user;
    }

    public void setPersona_user(String persona_user) {
        this.persona_user = persona_user;
    }

    public String getPersona_pass() {
        return persona_pass;
    }

    public void setPersona_pass(String persona_pass) {
        this.persona_pass = persona_pass;
    }

    public CRol getRol_id() {
        return rol_id;
    }

    public void setRol_id(CRol rol_id) {
        this.rol_id = rol_id;
    }

    public CPrivilegio getPrivilegio_id() {
        return privilegio_id;
    }

    public void setPrivilegio_id(CPrivilegio privilegio_id) {
        this.privilegio_id = privilegio_id;
    }

    public CGrupo getGrupo_id() {
        return grupo_id;
    }

    public void setGrupo_id(CGrupo grupo_id) {
        this.grupo_id = grupo_id;
    }
    
    
    
    
    
}
