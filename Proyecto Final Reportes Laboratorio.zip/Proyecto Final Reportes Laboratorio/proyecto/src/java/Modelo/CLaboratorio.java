/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author cerna
 */
public class CLaboratorio {
    private int lab_id;
    private String lab_nom;
    private int lab_numEquipos;
    
    public CLaboratorio(){
        lab_id=0;
        lab_nom="";
        lab_numEquipos=0;
    }

    public int getLab_id() {
        return lab_id;
    }

    public void setLab_id(int lab_id) {
        this.lab_id = lab_id;
    }

    public String getLab_nom() {
        return lab_nom;
    }

    public void setLab_nom(String lab_nom) {
        this.lab_nom = lab_nom;
    }

    public int getLab_numEquipos() {
        return lab_numEquipos;
    }

    public void setLab_numEquipos(int lab_numEquipos) {
        this.lab_numEquipos = lab_numEquipos;
    }
}
