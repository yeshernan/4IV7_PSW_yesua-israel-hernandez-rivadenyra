# chatjs

Chat Javascript




Como ejecutarlo

- npm install 
- node app.js
- accede a la URL http://127.0.0.1:8282


***** Si tienes alguna duda no dudes en contactar en mi blog *****  



***** Este y más proyectos en la ubicación :- https://www.configuroweb.com/ *****
