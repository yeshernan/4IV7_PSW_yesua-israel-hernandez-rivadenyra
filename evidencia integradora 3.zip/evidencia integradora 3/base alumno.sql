create database  reclamosalumnos;
USE reclamosalumnos;
Show tables;

CREATE TABLE basededatos (
    EQUIPO INT NOT NULL,
    monitor VARCHAR(50) NOT NULL,
     caja VARCHAR(50) NOT NULL,
    teclado varchar (50) not null,
    mouse varchar (50) not null,
    profesor_asignatura varchar (50) not null,
    PRIMARY KEY (EQUIPO)
);

CREATE TABLE nuevastecnologias (
    EQUIPO INT NOT NULL,
    monitor VARCHAR(50) NOT NULL,
     caja VARCHAR(50) NOT NULL,
    teclado varchar (50) not null,
    mouse varchar (50) not null,
    PRIMARY KEY (EQUIPO)
);
CREATE TABLE desarrollodesoftware (
    EQUIPO INT NOT NULL,
    monitor VARCHAR(50) NOT NULL,
     caja VARCHAR(50) NOT NULL,
    teclado varchar (50) not null,
    mouse varchar (50) not null,
    PRIMARY KEY (EQUIPO)
);
CREATE TABLE aulaXXI (
    EQUIPO INT NOT NULL,
    monitor VARCHAR(50) NOT NULL,
     caja VARCHAR(50) NOT NULL,
    teclado varchar (50) not null,
    mouse varchar (50) not null,
    PRIMARY KEY (EQUIPO)
);