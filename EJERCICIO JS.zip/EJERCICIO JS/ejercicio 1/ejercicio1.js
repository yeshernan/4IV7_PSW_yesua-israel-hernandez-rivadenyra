function validar (ejercicio1){
 value input
    alert(este seria lo que ganaria);
     return false;
}
var impuesto {¨
input*2/100
}