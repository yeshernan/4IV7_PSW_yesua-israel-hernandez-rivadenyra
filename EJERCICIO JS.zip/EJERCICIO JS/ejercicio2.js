function validar(input){
    value if input=0;
     alert(esto no se puede);
     return false
 
 }
 var sueldo (input)
 input=(input*15*/100)