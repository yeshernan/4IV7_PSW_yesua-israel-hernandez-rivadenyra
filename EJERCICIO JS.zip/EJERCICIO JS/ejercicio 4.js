function calcular_promedio(n1,n2,n3){
    var n1 = +document.getElementById(n1).value;
    var n2 = +document.getElementById(n2).value;
    var n3 = +document.getElementById(n3).value;
    let p  = (n1+n2+n3)/3;
    document.getElementById("promedio").innerText;
    

}